const express = require('express');
const bcrypt = require('bcryptjs');
const passport = require('passport');
const db = require('../db');

const router = express.Router();

// --- Registration ---
router.get('/register', (req, res) => {
  res.render('register');
});

router.post('/register', async (req, res) => {
  try {
    const { username, email, password, confirmPassword, name } = req.body;
    const cleanEmail = (email || '').toLowerCase().trim();
    const cleanUsername = (username || '').toLowerCase().trim();

    if (!cleanUsername || !cleanEmail || !password) {
      req.flash('error', 'Username, email and password are required.');
      return res.redirect('/register');
    }

    if (!/^[a-zA-Z0-9_-]{3,30}$/.test(cleanUsername)) {
      req.flash('error', 'Username must be 3-30 characters long and contain only letters, numbers, hyphens or underscores.');
      return res.redirect('/register');
    }

    if (password !== confirmPassword) {
      req.flash('error', 'Passwords do not match.');
      return res.redirect('/register');
    }

    if (password.length < 6) {
      req.flash('error', 'Password must be at least 6 characters.');
      return res.redirect('/register');
    }

    const existingUser = db.prepare('SELECT id FROM users WHERE LOWER(username) = ?').get(cleanUsername);
    if (existingUser) {
      req.flash('error', 'This username is already taken.');
      return res.redirect('/register');
    }

    const existingEmail = db.prepare('SELECT id FROM users WHERE LOWER(email) = ?').get(cleanEmail);
    if (existingEmail) {
      req.flash('error', 'An account with this email already exists.');
      return res.redirect('/register');
    }

    const hash = await bcrypt.hash(password, 10);
    const info = db.prepare(
      'INSERT INTO users (username, email, password_hash, name) VALUES (?, ?, ?, ?)'
    ).run(cleanUsername, cleanEmail, hash, (name || cleanUsername).trim());

    const newUser = db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid);

    req.login(newUser, (err) => {
      if (err) {
        req.flash('error', 'Account created, but error during automatic login. Please log in.');
        return res.redirect('/login');
      }
      req.flash('success', 'Account created successfully! Welcome to ScriptVault.');
      res.redirect('/dashboard');
    });
  } catch (err) {
    console.error(err);
    req.flash('error', 'A server error occurred. Please try again.');
    res.redirect('/register');
  }
});

// --- Login ---
router.get('/login', (req, res) => {
  res.render('login');
});

router.post('/login', (req, res, next) => {
  passport.authenticate('local', (err, user, info) => {
    if (err) return next(err);
    if (!user) {
      req.flash('error', (info && info.message) || 'Invalid login credentials.');
      return res.redirect('/login');
    }
    req.login(user, (err) => {
      if (err) return next(err);
      res.redirect('/dashboard');
    });
  })(req, res, next);
});

// --- Logout ---
router.post('/logout', (req, res, next) => {
  req.logout((err) => {
    if (err) return next(err);
    req.flash('success', 'You have been logged out.');
    res.redirect('/');
  });
});

// --- Google OAuth ---
router.get('/auth/google',
  passport.authenticate('google', { scope: ['profile', 'email'] })
);

router.get('/auth/google/callback',
  passport.authenticate('google', { failureRedirect: '/login', failureFlash: true }),
  (req, res) => {
    res.redirect('/dashboard');
  }
);

module.exports = router;
