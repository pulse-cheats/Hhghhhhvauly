const express = require('express');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const multer = require('multer');
const bcrypt = require('bcryptjs');
const db = require('../db');
const { ensureAuthenticated } = require('../middleware/auth');

const router = express.Router();

const UPLOAD_DIR = path.join(__dirname, '..', 'uploads');
const MAX_SIZE = 15 * 1024 * 1024; // 15MB

const ALLOWED_EXT = new Set([
  // scripts / text
  '.lua', '.py', '.js', '.ts', '.txt', '.json', '.sh', '.html', '.css', '.md',
  // images
  '.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg',
  // videos
  '.mp4', '.webm', '.mov',
]);

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    fs.mkdirSync(UPLOAD_DIR, { recursive: true });
    cb(null, UPLOAD_DIR);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const unique = crypto.randomBytes(16).toString('hex');
    cb(null, `${unique}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: MAX_SIZE },
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (!ALLOWED_EXT.has(ext)) {
      return cb(new Error(`File type ${ext || 'unknown'} is not supported.`));
    }
    cb(null, true);
  },
});

function sanitizeSlug(str) {
  return (str || '')
    .toString()
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_-]/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '') || 'default';
}

// --- Dashboard ---
router.get('/dashboard', ensureAuthenticated, (req, res) => {
  const myFiles = db.prepare(
    'SELECT * FROM files WHERE user_id = ? ORDER BY created_at DESC'
  ).all(req.user.id);

  res.render('dashboard', { myFiles, user: req.user });
});

// --- Upload Page ---
router.get('/upload', ensureAuthenticated, (req, res) => {
  res.render('upload', { maxSizeMB: MAX_SIZE / (1024 * 1024) });
});

router.post('/upload', ensureAuthenticated, (req, res) => {
  upload.single('file')(req, res, async (err) => {
    if (err) {
      req.flash('error', err.message || 'File upload error.');
      return res.redirect('/upload');
    }

    if (!req.file) {
      req.flash('error', 'Please select a file to upload.');
      return res.redirect('/upload');
    }

    const { title, description, project, filePassword } = req.body;

    if (filePassword && filePassword.trim().length > 0 && filePassword.length < 4) {
      fs.unlink(req.file.path, () => {});
      req.flash('error', 'Optional file password must be at least 4 characters if provided.');
      return res.redirect('/upload');
    }

    const fileTitle = (title || req.file.originalname).trim();
    const projectSlug = sanitizeSlug(project || 'default');
    const passwordHash = (filePassword && filePassword.trim().length > 0)
      ? await bcrypt.hash(filePassword, 10)
      : null;

    try {
      const info = db.prepare(`
        INSERT INTO files (user_id, project, title, description, original_name, stored_name, mime_type, size, password_hash)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        req.user.id,
        projectSlug,
        fileTitle,
        (description || '').trim(),
        req.file.originalname,
        req.file.filename,
        req.file.mimetype,
        req.file.size,
        passwordHash
      );

      req.flash('success', 'File uploaded successfully!');
      res.redirect(`/file/${info.lastInsertRowid}`);
    } catch (dbErr) {
      console.error(dbErr);
      fs.unlink(req.file.path, () => {});
      req.flash('error', 'Failed to save file information.');
      res.redirect('/upload');
    }
  });
});

// --- Raw / Loadstring Route: /:user/:project/:filename ---
// Compatible with: loadstring(game:HttpGet('https://domain/user/project/file.lua'))()
router.get('/raw/:username/:project/:filename', handleRawRequest);
router.get('/:username/:project/:filename', handleRawRequest);

function handleRawRequest(req, res, next) {
  const { username, project, filename } = req.params;

  // Exclude fixed app routes if collided
  const reserved = new Set(['dashboard', 'upload', 'file', 'login', 'register', 'logout', 'auth', 'public', 'style.css']);
  if (reserved.has(username.toLowerCase())) {
    return next();
  }

  const user = db.prepare('SELECT id, username FROM users WHERE LOWER(username) = ?').get(username.toLowerCase());
  if (!user) {
    return res.status(404).type('text/plain').send('-- ScriptVault: User not found: ' + username);
  }

  const file = db.prepare(`
    SELECT * FROM files
    WHERE user_id = ? AND LOWER(project) = ? AND LOWER(original_name) = ?
    ORDER BY created_at DESC
  `).get(user.id, project.toLowerCase(), filename.toLowerCase());

  if (!file) {
    return res.status(404).type('text/plain').send('-- ScriptVault: File not found: ' + filename + ' in project: ' + project);
  }

  // Check key/password parameter if file is password protected
  if (file.password_hash) {
    const key = req.query.key || req.query.password || req.headers['x-api-key'];
    if (!key || !bcrypt.compareSync(key, file.password_hash)) {
      return res.status(401).type('text/plain').send('-- ScriptVault: File is locked. Pass ?key=password to access.');
    }
  }

  const filePath = path.join(UPLOAD_DIR, file.stored_name);
  if (!fs.existsSync(filePath)) {
    return res.status(404).type('text/plain').send('-- ScriptVault: File missing from storage');
  }

  // Allow cross-origin requests (Roblox / Lua HttpGet / fetch)
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-api-key');
  res.setHeader('Cache-Control', 'no-cache');

  // Text/plain for scripts or appropriate mime type
  res.setHeader('Content-Type', file.mime_type || 'text/plain; charset=utf-8');
  res.sendFile(filePath);
}

// --- Web View File Page ---
router.get('/file/:id', (req, res) => {
  const file = db.prepare('SELECT f.*, u.username, u.name as owner_name FROM files f JOIN users u ON f.user_id = u.id WHERE f.id = ?').get(req.params.id);
  if (!file) {
    return res.status(404).render('message', {
      title: 'Not Found',
      text: 'The requested file does not exist or has been deleted.',
    });
  }

  const isOwner = req.user && req.user.id === file.user_id;
  const isUnlocked = !file.password_hash || isOwner || (req.session.unlockedFiles && req.session.unlockedFiles[file.id]);

  if (!isUnlocked) {
    return res.render('file-unlock', { file, error: req.flash('unlock_error')[0] });
  }

  const ext = path.extname(file.original_name).toLowerCase();
  const isImage = ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg'].includes(ext);
  const isVideo = ['.mp4', '.webm', '.mov'].includes(ext);
  const isText = !isImage && !isVideo;

  let textContent = null;
  if (isText) {
    const filePath = path.join(UPLOAD_DIR, file.stored_name);
    try {
      textContent = fs.readFileSync(filePath, 'utf8');
      if (textContent.length > 50000) {
        textContent = textContent.slice(0, 50000) + '\n\n... [File truncated for preview]';
      }
    } catch {
      textContent = '[Cannot read file content]';
    }
  }

  const token = signDownloadToken(file.id);

  res.render('file-view', {
    file,
    isOwner,
    isImage,
    isVideo,
    isText,
    textContent,
    token,
    host: req.get('host'),
    protocol: req.protocol,
  });
});

// --- Unlock File ---
router.post('/file/:id', async (req, res) => {
  const file = db.prepare('SELECT * FROM files WHERE id = ?').get(req.params.id);
  if (!file) {
    req.flash('error', 'File not found.');
    return res.redirect('/dashboard');
  }

  const { password } = req.body;
  if (!password) {
    req.flash('unlock_error', 'Please enter a password.');
    return res.redirect(`/file/${file.id}`);
  }

  const match = await bcrypt.compare(password, file.password_hash || '');
  if (!match) {
    req.flash('unlock_error', 'Incorrect password.');
    return res.redirect(`/file/${file.id}`);
  }

  if (!req.session.unlockedFiles) {
    req.session.unlockedFiles = {};
  }
  req.session.unlockedFiles[file.id] = true;

  res.redirect(`/file/${file.id}`);
});

// --- Download ---
router.get('/file/:id/download', (req, res) => {
  const file = db.prepare('SELECT * FROM files WHERE id = ?').get(req.params.id);
  if (!file) {
    return res.status(404).send('File not found');
  }

  const isOwner = req.user && req.user.id === file.user_id;
  const isUnlocked = !file.password_hash || isOwner || (req.session.unlockedFiles && req.session.unlockedFiles[file.id]);
  const tokenValid = req.query.token && verifyDownloadToken(file.id, req.query.token);

  if (!isUnlocked && !tokenValid) {
    req.flash('error', 'Access denied. You must unlock the file first.');
    return res.redirect(`/file/${file.id}`);
  }

  const filePath = path.join(UPLOAD_DIR, file.stored_name);
  if (!fs.existsSync(filePath)) {
    return res.status(404).send('File not found on server disk.');
  }

  res.download(filePath, file.original_name);
});

// --- Delete ---
router.post('/file/:id/delete', ensureAuthenticated, (req, res) => {
  const file = db.prepare('SELECT * FROM files WHERE id = ? AND user_id = ?').get(
    req.params.id,
    req.user.id
  );

  if (!file) {
    req.flash('error', 'File not found or permission denied.');
    return res.redirect('/dashboard');
  }

  const filePath = path.join(UPLOAD_DIR, file.stored_name);
  fs.unlink(filePath, () => {});

  db.prepare('DELETE FROM files WHERE id = ?').run(file.id);

  req.flash('success', 'File deleted.');
  res.redirect('/dashboard');
});

// --- Token helper for download ---
const SECRET = process.env.SESSION_SECRET || 'scriptvault-secret';

function signDownloadToken(fileId) {
  const hmac = crypto.createHmac('sha256', SECRET);
  hmac.update(`${fileId}:${Math.floor(Date.now() / (1000 * 60 * 30))}`); // 30 mins
  return hmac.digest('hex');
}

function verifyDownloadToken(fileId, token) {
  const expectedNow = signDownloadToken(fileId);
  if (crypto.timingSafeEqual(Buffer.from(token), Buffer.from(expectedNow))) return true;

  // Previous 30m window check
  const hmac = crypto.createHmac('sha256', SECRET);
  hmac.update(`${fileId}:${Math.floor(Date.now() / (1000 * 60 * 30)) - 1}`);
  const expectedPrev = hmac.digest('hex');
  try {
    return crypto.timingSafeEqual(Buffer.from(token), Buffer.from(expectedPrev));
  } catch {
    return false;
  }
}

module.exports = router;
