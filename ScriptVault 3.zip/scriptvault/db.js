const path = require('path');
const Database = require('better-sqlite3');

const db = new Database(path.join(__dirname, 'data', 'scriptvault.sqlite'));

db.pragma('journal_mode = WAL');

// --- Tables creation ---
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT,
  google_id TEXT UNIQUE,
  name TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS files (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  project TEXT NOT NULL DEFAULT 'default',
  title TEXT NOT NULL,
  description TEXT,
  original_name TEXT NOT NULL,
  stored_name TEXT NOT NULL,
  mime_type TEXT,
  size INTEGER NOT NULL,
  password_hash TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_files_user_id ON files(user_id);
CREATE INDEX IF NOT EXISTS idx_files_lookup ON files(user_id, project, original_name);
`);

// Safe migration if tables already exist without username/project
try {
  db.exec(`ALTER TABLE users ADD COLUMN username TEXT;`);
} catch (e) {}

try {
  db.exec(`ALTER TABLE files ADD COLUMN project TEXT NOT NULL DEFAULT 'default';`);
} catch (e) {}

try {
  db.exec(`ALTER TABLE files ADD COLUMN is_public INTEGER NOT NULL DEFAULT 1;`);
} catch (e) {}

// Make sure username column has index or unique constraint
try {
  db.exec(`CREATE UNIQUE INDEX IF NOT EXISTS idx_users_username ON users(username);`);
} catch (e) {}

module.exports = db;
