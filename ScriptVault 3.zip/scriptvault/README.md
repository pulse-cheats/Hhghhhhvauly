# ScriptVault

A lightweight script hosting platform built for Lua / Roblox scripts, documents, and media.
Features direct `loadstring(game:HttpGet(...))()` raw links, project organization, and optional file protection.

## Features

- **Raw Lua Loadstring Support:** Direct URLs formatted as `https://domain/:username/:project/:filename`.
- **Project Structure:** Organize scripts by project / category.
- **English UI:** Clean, modern, responsive interface.
- **Direct Copy:** 1-click copy of ready-to-run `loadstring(game:HttpGet(...))()` snippets in script view.
- **Optional File Passwords:** Keep scripts public for execution or locked behind a password.
- **Local & Google Authentication:** Session-based auth with SQLite persistence.

## Setup & Running

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Configure environment:**
   Copy `.env.example` to `.env` (or configure port and session secret):
   ```env
   PORT=3000
   SESSION_SECRET=your-secret-key
   BASE_URL=http://localhost:3000
   ```

3. **Start the server:**
   ```bash
   npm start
   ```

4. **Lua HttpGet Usage Example:**
   ```lua
   loadstring(game:HttpGet('http://localhost:3000/sotos/roblox-hub/script.lua'))()
   ```
